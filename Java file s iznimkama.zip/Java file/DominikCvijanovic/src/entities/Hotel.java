package entities;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Radenje hotela sa sobama i osobljem
 *
 * @see Cancelable
 *
 */

public final class Hotel implements Cancelable {
    private static final Logger log = LoggerFactory.getLogger(Hotel.class);

    private final String name;        // obavezno
    private final String city;        // obavezno
    private final String address;     // obavezno
    private final Room[] rooms;       // opcionalno
    private final Staff[] staff;      // opcionalno
    private final boolean cancellable; // opcionalno


    private Hotel(Builder builder) {
        log.trace("Ulazak u builder.");

        this.name = builder.name;
        this.city = builder.city;
        this.address = builder.address;
        this.rooms = builder.rooms;
        this.staff = builder.staff;
        this.cancellable = builder.cancellable;
    }

    public static class Builder {
        // obavezna polja
        private final String name;
        private final String city;
        private final String address;

        // opcionalna polja
        private Room[] rooms;
        private Staff[] staff;
        private boolean cancellable;

        public Builder(String name, String city, String address) {
            this.name = name;
            this.city = city;
            this.address = address;
            log.info("Pokrenut unos obaveznih parametara hotela.");
        }

        public Builder setRooms(Room[] rooms) {
            this.rooms = rooms;
            return this;
        }

        public Builder setStaff(Staff[] staff) {
            this.staff = staff;
            return this;
        }

        public Builder setCancellable(boolean cancellable) {
            this.cancellable = cancellable;
            return this;
        }


        public Hotel build() {
            log.info("Napravljen je build hotela!");

            return new Hotel(this);
        }
    }

    @Override
    public boolean canBeCancelled() {
        log.info("Napravljen je cancella hotela!");
        return cancellable;
    }

    public String getName() { return name; }
    public String getCity() { return city; }
    public String getAddress() { return address; }
    public Room[] getRooms() { return rooms; }
    public Staff[] getStaff() { return staff; }
    public boolean isCancellable() { return cancellable; }
}
