package entities;

/**
 * Baca gresku za krivo unesenog gosta hotela
 */

public class InvalidGuestDataException extends Exception {
    public InvalidGuestDataException(String message) {
        super(message);
    }
}

