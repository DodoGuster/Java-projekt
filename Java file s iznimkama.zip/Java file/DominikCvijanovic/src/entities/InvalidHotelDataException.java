package entities;

/**
 * Baca iznimku za krivo unesene parametre hotela
 */

public class InvalidHotelDataException extends RuntimeException {
    public InvalidHotelDataException(String message) {
        super(message);
    }
}
