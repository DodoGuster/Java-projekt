package app;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Scanner;
import entities.*;
import java.math.BigDecimal;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Kreiranje booking sustava pomocu glavne metode
 *
 * Kreira booking sustav za rezervaciju hotela sa dodatnim unosom osoblja i soba.
 *
 * @author Dominik Cvijanovic
 */
public class Main {
    private static final int NUMBER = 2;
    static Logger log = LoggerFactory.getLogger(Main.class);

    public static void main(String[] args) {

        log.info("Pokrenut program!");

        Hotel[] hotels = new Hotel[NUMBER];
        Guest[] guest = new Guest[NUMBER];
        Reservation[] reservation = new Reservation[NUMBER];
        Scanner unos = new Scanner(System.in);

/**
 * Pocinje unos hotela i ostalih stvari u hotelu
 *
 * @param hotel unos podataka za hotel
 * @throws InvalidHotelDataException ako su unosi prazni
 * @throws IllegalArgumentException ako je cijena nocenja manja od nule
 */
        int br2 = 0;
        log.info("Ulaz u unos hotela i osoblja!");
        System.out.println("Unos hotela i soba!");
        while (br2 < NUMBER) {
            System.out.println("Unesite ime " + (br2+1) + ". hotela:");
            String imeHotela = unos.nextLine();
            System.out.println("Unesite grad u kojem se hotel nalazi: ");
            String city = unos.nextLine().trim();
            System.out.println("Unesite adresu hotela:");
            String adresa = unos.nextLine();
            try{
                if(imeHotela.isEmpty() || adresa.isEmpty() || city.isEmpty())
                    throw new InvalidHotelDataException("Krivi unos podataka za " + (br2+1) + "hotel!");

            }
            catch(InvalidHotelDataException e){
                System.out.println(e.getMessage());
                log.error(e.getMessage());
                continue;
            }
            int br = 0; // brojac soba
            Room[] rooms = new Room[NUMBER];

            while (br < NUMBER) {
                boolean valid = false;
                do {
                    System.out.println("Unesite opis " + (br + 1) + ". sobe u hotelu:");
                    String opis = unos.nextLine();

                    System.out.println("Unesite broj kreveta te sobe:");
                    int broj = unos.nextInt();

                    System.out.println("Unesite cijenu noćenja u toj sobi: ");
                    BigDecimal nocenje = unos.nextBigDecimal();
                    unos.nextLine(); // pročisti scanner

                    try {
                        // Unchecked iznimka – negativna ili nula cijena
                        if (nocenje.compareTo(BigDecimal.ZERO) <= 0) {
                            throw new IllegalArgumentException("Cijena noćenja mora biti veća od 0!");
                        }

                        // Dodatne validacije
                        if (opis.isEmpty() || opis.length() < 5 || broj < 1) {
                            System.out.println("Krivi upis, ponovite upis " + (br + 1) + ". sobe");
                        } else {
                            // ako je sve u redu, kreiraj sobu i izađi iz petlje
                            rooms[br++] = new Room(br, nocenje, opis, broj);
                            valid = true;
                        }

                    } catch (IllegalArgumentException e) {
                        log.error(e.getMessage());
                        System.out.println("⚠️ " + e.getMessage());
                    }

                } while (!valid);
            }
            log.info("Unos hotela je zavrsen!");
            log.trace("Broj kreiranih hotela: " + NUMBER);

            br = 0;
                System.out.println("Unjeli ste sobe, slijedi unos osoblja hotela!\nUnesite koliko zaposlenika ima hotel(npr. 3):"); int brZaposlenika =  unos.nextInt(); unos.nextLine();
                Staff[] staff = new Staff[brZaposlenika];
                for (int i = 0; i < brZaposlenika; i++) {
                    System.out.println("Unesite ime " + (i + 1) + ". zaposlenika:");  String ime = unos.nextLine();
                    System.out.println("Unesite prezime " + (i + 1) + ". zaposlenika:");  String prezime = unos.nextLine();
                    System.out.println("Unesite vrstu posla " + (i + 1) + ". zaposlenika(npr. konobar):");  String vrstaPosla = unos.nextLine();
                    System.out.println("Unesite placu " + (i + 1) + ". zaposlenika(npr. 1100):");  BigDecimal placa = unos.nextBigDecimal(); unos.nextLine();
                    System.out.println("Unesite dob " + (i + 1) + ". zaposlenika(npr. 31):");  BigDecimal dob = unos.nextBigDecimal(); unos.nextLine();
                    Salary salary = new Salary(placa); staff[i] = new Staff(ime, prezime, vrstaPosla, salary,dob);
                }
                System.out.println("Moze li se rezervacija hotela otkazati nakon rezervacije(Upisite: true ili false):"); Boolean cancelable = unos.nextBoolean(); unos.nextLine();
                hotels[br2++] = new Hotel.Builder(imeHotela,city,adresa)
                        .setRooms(rooms)
                        .setStaff(staff)
                        .setCancellable(cancelable)
                        .build();
                log.info("Pokusaj kreiranja hotela u mainu!");
        }
        br2 = 0;

        /**
         * Unosenje gostiju u odvojeno polje
         *
         * Unos gostiju u sustav bookinga
         *
         * @see Guest
         */

        log.info("Pokrenut unos gostiju!");
        while (br2 < NUMBER) {
            System.out.println("Unesite ime " + (br2 + 1) + ". gosta:");
            String ime = unos.nextLine();
            System.out.println("Unesite prezime " + (br2 + 1) + ". gosta:");
            String prezime = unos.nextLine();
            System.out.println("Unesite dob (npr. 31) " + (br2 + 1) + ". gosta:");
            BigDecimal dob = unos.nextBigDecimal();
            unos.nextLine();
            System.out.println("Unesite email gosta(ime@gmail.com): ");
            String email = unos.nextLine();
            try {
                if (ime.isEmpty() || prezime.isEmpty() || email.isEmpty() ||
                        dob.compareTo(BigDecimal.ONE) < 0 || dob.compareTo(new BigDecimal("100")) > 0) {
                    throw new InvalidGuestDataException("Pogrešan unos gosta — podaci nisu ispravni!");
                }
                guest[br2++] = new Guest(ime, prezime, email, dob);
            } catch (InvalidGuestDataException e) {
                System.out.println(e.getMessage());
            }

        }
        br2 = 0;
        log.info("Zavrsen unos gostiju!");

/**
 * Pokretanje glavnog dijela rezervacije
 *
 * Korisnik rezervira hotel te moze birati grad i sobu
 *
 * @param reservation objekt za radenje rezervacije
 * @throws java.time.format.DateTimeParseException ako je unos datuma kriv
 * @see hotels
 */
        log.info("Ulaz u rezervaciju hotela!");
        System.out.println("*** REZERVIRAJ SVOJ HOTEL ***\n");

        while (br2 < NUMBER) {
            int brojHotela = 0;
            System.out.println("Unesite grad u kojem želite rezervirati hotel: ");
            String grad = unos.nextLine().trim();;
            System.out.println("Odaberite hotel:");
            for (int i = 0; i < NUMBER; i++) {
                if (hotels[i].getCity().trim().equalsIgnoreCase(grad.trim())){
                    System.out.println((i + 1) + ". HOTEL, grad je: " + hotels[i].getCity() + ", hotel je: " + hotels[i].getName() + ", njegova adresa je: " + hotels[i].getAddress());
                }
          //  else  System.out.println((i + 1) +  "grad" + hotels[i].getCity() + " hotel: " + hotels[i].getName() +  "ne zadovoljava uvjet");
            }
                System.out.println("Unesite broj hotela koji zelite rezervirati(npr. 1): ");
                while (brojHotela < 1 || brojHotela > NUMBER) {
                    brojHotela = unos.nextInt();
                    if(brojHotela < 1 || brojHotela > NUMBER){System.out.println("Krivi unos, ponovite unos brojea hotela!"); brojHotela=0;}
                    else if(!hotels[brojHotela-1].getCity().equalsIgnoreCase(grad)){brojHotela=0; System.out.println("Krivi unos, ponovite unos brojea hotela!");}
                }
                unos.nextLine();
                System.out.println("ODABIR SOBE:\nUnesite maksimalnu cijenu za jednu noc:");
                BigDecimal maksNoc = unos.nextBigDecimal();
                unos.nextLine();
                Room[] sobe = hotels[brojHotela - 1].getRooms();
                for (int j = 0; j < sobe.length; j++) {
                    BigDecimal cijena = hotels[brojHotela - 1].getRooms()[j].getPricePerNight();
                    if (cijena.compareTo(maksNoc) <= 0) System.out.println("Broj sobe: " + (j + 1) + "., " + "opis sobe: " +
                            hotels[brojHotela - 1].getRooms()[j].getDescription() + ", brojkreveta: " + hotels[brojHotela - 1].getRooms()[j].getNumberOfBeds() + ", cijena nocenja je: " + hotels[brojHotela - 1].getRooms()[j].getPricePerNight());
                }
                System.out.println("Unesite broj sobe koju zelite: ");
                int brojSobe = unos.nextInt();
                unos.nextLine();

                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd.MM.yyyy");
                LocalDate startDate = null;
                LocalDate endDate = null;
            boolean provjera = false;
            do {
                try {
                    System.out.println("Unesite pocetni datum (01.01.2020): ");
                    startDate = LocalDate.parse(unos.nextLine(), formatter);

                    System.out.println("Unesite zavrsni datum (01.01.2020): ");
                    endDate = LocalDate.parse(unos.nextLine(), formatter);
                    provjera = true;

                } catch (java.time.format.DateTimeParseException e) {
                    e.printStackTrace();
                    System.out.println("Krivi format datuma! Molimo upišite točno u obliku dd.MM.yyyy");
                }

            } while (!provjera);

            System.out.println("Za potvrdu rezervacije unesite Vase ime i prezime!\nUnos imena: ");
                String ime = unos.nextLine();
                System.out.println("Unos prezimena: ");
                String prezime = unos.nextLine();
                Guest gostUnos = null;
                int br = 0;
                while(br == 0){
                for (int i = 0; i < NUMBER; i++) {
                    if (guest[i].getName().equalsIgnoreCase(ime)){
                        if (guest[i].getSurname().equalsIgnoreCase(prezime)) gostUnos = guest[i]; br++;}}
                    if(br == 0){ System.out.println("Korisnik ne postoji ili je krivo unesen, ponovite upis!");
                        System.out.println("Unos imena: ");
                        ime = unos.nextLine();
                        System.out.println("Unos prezimena: ");
                        prezime = unos.nextLine();
                    }
                }
                System.out.println("Hvala na rezervaciji!");
                reservation[br2++] = new Reservation(hotels[brojHotela - 1], hotels[brojHotela - 1].getRooms()[brojSobe - 1], startDate, endDate, gostUnos);
            }
        log.info("Rezrvacija hotela odradena!");

        /**
         * Sortiranje clanova bookinga po starosti
         *
         * @param guest objekt za sortiranje
         * @return nema
         */
        Person[] persons = new Person[guest.length];
        for (int i = 0; i < guest.length; i++) {
            persons[i] = guest[i];
        }
//        Arrays.sort(persons,(p1,p2)->{
//            return p2.getAge().compareTo(p1.getAge());
//        });
        log.info("Pokusaj sortiranja!");
        Arrays.sort(persons, new Comparator<Person>() {
            @Override
            public int compare(Person o1, Person o2) {
                return o1.getAge().compareTo(o2.getAge());
            }
        });

        for (Person p : persons) {
            System.out.println(p.getName() + " " + p.getSurname() + " — " + p.getAge());
        }


        unos.close();
        }
    }
