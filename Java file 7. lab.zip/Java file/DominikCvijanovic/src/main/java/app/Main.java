package app;

import app.entities.UI.AdminUI;
import app.entities.UI.UserIU;
import app.entities.services.BackupService;
import app.entities.services.GuestService;
import app.entities.services.HotelService;
import app.entities.services.ReservationService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import app.entities.services.XmlLog;


import java.util.Scanner;

public class Main {

    static Logger log = LoggerFactory.getLogger(Main.class);

    public static void main(String[] args) {

        log.info("Pokrenut program!");

        Scanner unos = new Scanner(System.in);

        HotelService hotelService = new HotelService();
        GuestService guestService = new GuestService();
        ReservationService reservationService = new ReservationService();
        BackupService backupService = new BackupService();
        XmlLog xmlLogService = new XmlLog();

        hotelService.loadFromJson();
        guestService.loadFromJson();
        reservationService.loadFromJson();

        AdminUI admin = new AdminUI(hotelService);
        UserIU user = new UserIU(hotelService, guestService, reservationService);

        boolean radi = true;

        while (radi) {
            System.out.println("\n=== BOOKING HOTELA ===");
            System.out.println("1 - Unos / ažuriranje hotela i osoblja");
            System.out.println("2 - Unos gostiju i rezervacija hotela");
            System.out.println("3 - Kreiranje backup.bin");
            System.out.println("4 - Učitavanje backup.bin (prepisivanje podataka)");
            System.out.println("0 - Izlaz");
            System.out.print("Odaberite opciju: ");

            String linija = unos.nextLine();
            int izbor;
            try {
                izbor = Integer.parseInt(linija);
            } catch (NumberFormatException e) {
                System.out.println("Krivi unos, upišite broj!");
                continue;
            }

            switch (izbor) {
                case 1 -> {
                    xmlLogService.log("Odabir opcije 1");
                    admin.run(unos);
                }
                case 2 -> {
                     xmlLogService.log("Odabir opcije 2");
                    user.run(unos);
                }
                case 3 -> {
                     xmlLogService.log("Odabir opcije 3");
                    backupService.createBackup(hotelService, guestService, reservationService);
                }
                case 4 -> {
                     xmlLogService.log("Odabir opcije 4");
                    backupService.restoreBackup(hotelService, guestService, reservationService);
                }
                case 0 -> {
                     xmlLogService.log("Odabir opcije 0 - izlaz");
                    radi = false;
                }
                default -> System.out.println("Nepostojeća opcija!");
            }
        }

        unos.close();
        log.info("Program završen.");
    }
}
