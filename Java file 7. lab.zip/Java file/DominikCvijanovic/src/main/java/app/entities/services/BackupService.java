package app.entities.services;

import app.entities.backup.BackupData;

import java.io.*;

public class BackupService {

    private static final String BACKUP_FILE = "backup.bin";

    public void createBackup(HotelService hs,
                             GuestService gs,
                             ReservationService rs) {
        BackupData data = new BackupData(
                hs.getAll(),
                gs.getAll(),
                rs.getAll()
        );
        try (ObjectOutputStream oos =
                     new ObjectOutputStream(new FileOutputStream(BACKUP_FILE))) {
            oos.writeObject(data);
            System.out.println("Backup je kreiran u " + BACKUP_FILE);
        } catch (IOException e) {
            System.out.println("Greška pri kreiranju backup-a: " + e.getMessage());
        }
    }

    public void restoreBackup(HotelService hs,
                              GuestService gs,
                              ReservationService rs) {
        try (ObjectInputStream ois =
                     new ObjectInputStream(new FileInputStream(BACKUP_FILE))) {

            BackupData data = (BackupData) ois.readObject();

            hs.replaceAll(data.getHotels());
            gs.replaceAll(data.getGuests());
            rs.replaceAll(data.getReservations());

            System.out.println("Backup učitan i prepisao trenutne podatke.");

        } catch (FileNotFoundException e) {
            System.out.println("backup.bin ne postoji!");
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Greška pri učitavanju backup-a: " + e.getMessage());
        }
    }
}
