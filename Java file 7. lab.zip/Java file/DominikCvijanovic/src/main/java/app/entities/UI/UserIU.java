package app.entities.UI;
import app.entities.Hotel.City;
import app.entities.Hotel.Hotel;
import app.entities.Hotel.Room;
import app.entities.Person.Guest;
import app.entities.Person.InvalidGuestDataException;
import app.entities.Reservations.Reservation;
import app.entities.services.GuestService;
import app.entities.services.HotelService;
import app.entities.services.ReservationService;
import app.entities.util.PrintUtils;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
public class UserIU {

    private static final int NUMBER = 2;

    private final HotelService hotelService;
    private final GuestService guestService;
    private final ReservationService reservationService;

    public UserIU(HotelService hotelService,
                  GuestService guestService,
                  ReservationService reservationService) {
        this.hotelService = hotelService;
        this.guestService = guestService;
        this.reservationService = reservationService;
    }

    public void run(Scanner unos) {
        unosGostiju(unos);
        rezervacijaHotela(unos);
    }

    private void unosGostiju(Scanner unos) {
        System.out.println("=== UNOS GOSTIJU ===");

        System.out.print("Koliko gostiju želite unijeti? ");
        int brojGostiju = 0;
        while (brojGostiju <= 0) {
            try {
                brojGostiju = Integer.parseInt(unos.nextLine());
                if (brojGostiju <= 0) {
                    System.out.print("Unesite broj veći od 0: ");
                }
            } catch (NumberFormatException e) {
                System.out.print("Krivi unos, upišite cijeli broj: ");
            }
        }

        int br2 = 0;

        while (br2 < brojGostiju) {
            System.out.println("\nGost #" + (br2 + 1));

            System.out.print("Unesite ime: ");
            String ime = unos.nextLine();

            System.out.print("Unesite prezime: ");
            String prezime = unos.nextLine();

            // tražimo postojeći po imenu i prezimenu
            var existing = guestService.getAll().stream()
                    .filter(g -> g.getName().equalsIgnoreCase(ime)
                            && g.getSurname().equalsIgnoreCase(prezime))
                    .findFirst();

            if (existing.isPresent()) {
                Guest g = existing.get();
                System.out.println("Pronađen gost: " + g.getName() + " " + g.getSurname());
                br2++;
                continue; // ne unosimo ponovno
            }

            System.out.println("Gost ne postoji. Kreiramo novog.");

            System.out.print("Unesite dob (npr. 31): ");
            BigDecimal dob = unos.nextBigDecimal();
            unos.nextLine(); // pojede newline

            System.out.print("Unesite email: ");
            String email = unos.nextLine();

            guestService.addGuest(new Guest(ime, prezime, email, dob));
            System.out.println("Gost dodan.");
            br2++;
        }

        System.out.println("\nZavrsen unos gostiju!");
    }

    private void rezervacijaHotela(Scanner unos) {
        System.out.println("*** REZERVIRAJ SVOJ HOTEL ***\n");

        var hotels = hotelService.getAll();
        var guests = guestService.getAll();

        if (hotels.isEmpty()) {
            System.out.println("Nema hotela u sustavu. Prvo unesite hotele (opcija 1).");
            return;
        }
        if (guests.isEmpty()) {
            System.out.println("Nema gostiju u sustavu. Prvo unesite goste (opcija 2).");
            return;
        }

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd.MM.yyyy");

        boolean dalje = true;
        while (dalje) {
            // 1) odabir grada
            System.out.println("Unesite grad u kojem želite rezervirati hotel (ZAGREB / OSIJEK): ");
            City grad = null;
            while (grad == null) {
                try {
                    grad = City.valueOf(unos.nextLine().trim().toUpperCase());
                } catch (IllegalArgumentException e) {
                    System.out.println("Nepoznat grad! Pokušajte ponovno.");
                }
            }

            // 2) ispis hotela u tom gradu
            System.out.println("Odaberite hotel:");
            for (int i = 0; i < hotels.size(); i++) {
                Hotel h = hotels.get(i);
                if (h.getCity() != null && h.getCity().equals(grad)) {
                    System.out.println((i + 1) + ". HOTEL, grad: " + h.getCity() +
                            ", ime: " + h.getName() +
                            ", adresa: " + h.getAddress());
                }
            }

            // 3) odabir hotela
            int brojHotela = 0;
            System.out.println("Unesite broj hotela koji zelite rezervirati (npr. 1): ");
            while (brojHotela < 1 || brojHotela > hotels.size()) {
                try {
                    brojHotela = Integer.parseInt(unos.nextLine());
                    if (brojHotela < 1 || brojHotela > hotels.size()) {
                        System.out.println("Krivi unos, ponovite unos broja hotela!");
                        brojHotela = 0;
                    }
                } catch (NumberFormatException e) {
                    System.out.println("Unesite broj hotela kao cijeli broj!");
                }
            }

            Hotel odabraniHotel = hotels.get(brojHotela - 1);
            Map<Integer, Room> sobe = odabraniHotel.getRooms();

            // 4) sobe + cijena
            System.out.println("ODABIR SOBE:\nUnesite maksimalnu cijenu za jednu noc:");
            BigDecimal maksNoc = unos.nextBigDecimal();
            unos.nextLine();

            System.out.println("Dostupne sobe do cijene " + maksNoc + ":");
            for (Room room : sobe.values()) {
                BigDecimal cijena = room.getPricePerNight();
                if (cijena.compareTo(maksNoc) <= 0) {
                    System.out.println("Broj sobe: " + room.getRoomNumber() +
                            ", opis: " + room.getDescription() +
                            ", broj kreveta: " + room.getNumberOfBeds() +
                            ", cijena: " + room.getPricePerNight());
                }
            }

            System.out.println("Unesite broj sobe koju zelite: ");
            int brojSobe = Integer.parseInt(unos.nextLine());
            Room odabranaSoba = sobe.get(brojSobe);
            if (odabranaSoba == null) {
                System.out.println("Ne postoji soba s tim brojem, uzimam prvu sobu iz ponude.");
                odabranaSoba = sobe.values().iterator().next();
            }

            // 5) datumi
            LocalDate startDate = null;
            LocalDate endDate = null;
            boolean provjera = false;
            do {
                try {
                    System.out.println("Unesite pocetni datum (01.01.2020): ");
                    startDate = LocalDate.parse(unos.nextLine(), formatter);
                    System.out.println("Unesite zavrsni datum (01.01.2020): ");
                    endDate = LocalDate.parse(unos.nextLine(), formatter);
                    provjera = true;
                } catch (java.time.format.DateTimeParseException e) {
                    System.out.println("Krivi format datuma! Molimo upišite točno u obliku dd.MM.yyyy");
                }
            } while (!provjera);

            // 6) potvrda gosta (ime + prezime)
            System.out.println("Za potvrdu rezervacije unesite Vase ime i prezime!");
            System.out.print("Unos imena: ");
            String ime = unos.nextLine();
            System.out.print("Unos prezimena: ");
            String prezime = unos.nextLine();

            Guest gostUnos = guests.stream()
                    .filter(g -> g.getName().equalsIgnoreCase(ime)
                            && g.getSurname().equalsIgnoreCase(prezime))
                    .findFirst()
                    .orElse(null);

            if (gostUnos == null) {
                System.out.println("Korisnik ne postoji ili je krivo unesen!");
            } else {
                reservationService.addReservation(
                        new Reservation(odabraniHotel,
                                odabranaSoba, startDate, endDate, gostUnos)
                );
                System.out.println("Hvala na rezervaciji!");
            }

            // 7) želiš li još?
            System.out.print("Želite li napraviti još jednu rezervaciju? (da/ne): ");
            String odgovor = unos.nextLine().trim().toLowerCase();
            if (!odgovor.equals("da")) {
                dalje = false;
            }
        }

        System.out.println("Rezervacije završene.");
    }

}
