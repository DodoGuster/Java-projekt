package app.entities.services;

import app.entities.Hotel.Room;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class RoomService {

    private final List<Room> rooms = new ArrayList<>();

    // Vjerojatno bi se ovo trebalo zvati addRoom, ali ne diram da ti ne razbijem ostatak koda 🙂
    public void addHotel(Room r) {
        rooms.add(r);
    }

    public List<Room> getAll() {
        return rooms;
    }

    /**
     * Pronalazi sobu po broju sobe.
     * Vraća Optional<Room>.
     */
    public Optional<Room> findByNumber(int roomNumber) {
        return rooms.stream()
                .filter(r -> r.getRoomNumber() == roomNumber)
                .findFirst();
    }
}
