package app.entities.Hotel;


import app.entities.Hotel.Hotel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * Unosenje soba za hotel
 *
 * @see Hotel
 */

public class Room implements Serializable {
    private static final Logger log = LoggerFactory.getLogger(Room.class);

    int roomNumber;
    BigDecimal pricePerNight;
    private String description;   // npr. "Soba za jednu osobu"
    private int numberOfBeds;

    public Room() {}

    public Room(int number, BigDecimal pricePerNight,  String description, int numberOfBeds) {
        this.roomNumber = number;
        this.pricePerNight = pricePerNight;
        this.description = description;
        this.numberOfBeds = numberOfBeds;

        log.info("Soba kreirana sa parametrima: {} {} {} {} {}!", number, pricePerNight, description, numberOfBeds);
    }
    public int getRoomNumber() {
        return roomNumber;
    }
    public BigDecimal getPricePerNight() {
        return pricePerNight;
    }
    public void setRoomNumber(int roomNumber) {
        this.roomNumber = roomNumber;
    }
    public void setPricePerNight(BigDecimal pricePerNight) {
        this.pricePerNight = pricePerNight;
    }
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }
    public int getNumberOfBeds() {
        return numberOfBeds;
    }
    public void setNumberOfBeds(int numberOfBeds) {
        this.numberOfBeds = numberOfBeds;
    }

    @Override
    public String toString() {
        return "Soba " + roomNumber +
                " | opis: " + description +
                " | kreveta: " + numberOfBeds +
                " | cijena/noć: " + pricePerNight;
    }



}

