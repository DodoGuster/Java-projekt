package app.entities.Person;
import java.math.BigDecimal;

/**
 * Baca gresku za krivo unesenog gosta hotela
 */
 // ili tvoj package
public class InvalidGuestDataException extends Exception {

    private final String name;
    private final String surname;
    private final String email;
    private final BigDecimal age;
    private final String reason;

    public InvalidGuestDataException(String name, String surname, String email,
                                     BigDecimal age, String reason) {
        super("Neispravan gost: " + name + " " + surname +
                " (email: " + email + ", dob: " + age + ") – " + reason);
        this.name = name;
        this.surname = surname;
        this.email = email;
        this.age = age;
        this.reason = reason;
    }

}


