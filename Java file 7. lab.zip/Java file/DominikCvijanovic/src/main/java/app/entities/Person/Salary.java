package app.entities.Person;


import java.io.Serializable;
import java.math.BigDecimal;

/**
 * Spremanje placa zaposlenika
 *
 * @param salary
 */

import java.io.Serializable;
import java.math.BigDecimal;

public record Salary(BigDecimal amount) implements Serializable {
}

