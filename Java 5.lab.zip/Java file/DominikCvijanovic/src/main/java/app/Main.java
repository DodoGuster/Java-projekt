package app;

import java.util.*;

import app.entities.UI.AdminUI;
import app.entities.UI.UserIU;
import app.entities.services.GuestService;
import app.entities.services.HotelService;
import app.entities.services.ReservationService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Main {

    static Logger log = LoggerFactory.getLogger(Main.class);

    public static void main(String[] args) {

        log.info("Pokrenut program!");

        Scanner unos;
        //unos = new Scanner(System.in);
      try {
            unos = new Scanner(Main.class.getResourceAsStream("/input.txt"));

        } catch (Exception e) {
            System.out.println("Ne mogu učitati datoteku input.txt! Provjeri da je u src/main/resources.");
            log.trace(e.getMessage());
            return;
        }

        HotelService hotelService = new HotelService();
        GuestService guestService = new GuestService();
        ReservationService reservationService = new ReservationService();

        AdminUI admin = new AdminUI(hotelService);
        admin.run(unos);   // hoteli + sobe + staff

        UserIU user = new UserIU(hotelService, guestService, reservationService);
        user.run(unos);    // gosti + rezervacije

        unos.close();
    }
}
