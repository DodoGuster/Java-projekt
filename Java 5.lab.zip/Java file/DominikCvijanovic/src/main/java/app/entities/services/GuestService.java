package app.entities.services;

import app.entities.Person.Guest;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class GuestService {

    private final List<Guest> guests = new ArrayList<>();

    public void addGuest(Guest guest) {
        guests.add(guest);
    }

    public List<Guest> getAll() {
        return guests;
    }

    /**
     * Pronalazi gosta po imenu ili prezimenu.
     * Vraća Optional<Guest>.
     */
    public Optional<Guest> findByName(String name) {
        return guests.stream()
                .filter(g -> g.getName().equalsIgnoreCase(name)
                        || g.getSurname().equalsIgnoreCase(name))
                .findFirst(); // Optional<Guest>
    }
}
