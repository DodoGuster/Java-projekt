package app.entities.Hotel;

import app.entities.Hotel.Room;
import app.entities.Person.Staff;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.*;


/**
 * Radenje hotela sa sobama i osobljem, koristeći kolekcije (Map, Set)
 *
 * @see Cancelable
 */
public final class Hotel implements Cancelable {
    private static final Logger log = LoggerFactory.getLogger(Hotel.class);

    private final String name;             // obavezno
    private final City city;               // obavezno
    private final String address;          // obavezno
    private final Map<Integer, Room> rooms;
    private final List<Staff> staff;
    private final boolean cancellable;     // opcionalno
    private final HotelType type;          // enumeracija (npr. LUXURY, BUSINESS...)

    public Hotel(Builder builder) {
        log.trace("Ulazak u builder.");
        this.name = builder.name;
        this.city = builder.city;
        this.address = builder.address;
        this.rooms = builder.rooms;
        this.staff = builder.staff;
        this.cancellable = builder.cancellable;
        this.type = builder.type;
    }

    /** Enumeracija za tip hotela */
    public enum HotelType {
        LUXURY, BUSINESS, BOUTIQUE, FAMILY, BUDGET
    }

    /** Builder klasa */
    public static class Builder {
        // obavezna polja
        private final String name;
        private final City city;
        private final String address;

        // opcionalna polja (kolekcije)
        private Map<Integer, Room> rooms = new HashMap<>();
        private List<Staff> staff = new ArrayList<>();
        private boolean cancellable;
        private HotelType type = HotelType.BUSINESS;

        public Builder(String name, City city, String address) {
            this.name = name;
            this.city = city;
            this.address = address;
            log.info("Pokrenut unos obaveznih parametara hotela.");
        }

        public Builder setRooms(Map<Integer, Room> rooms) {
            this.rooms = rooms;
            return this;
        }

        public Builder setStaff(List<Staff> staff) {
            this.staff = staff;
            return this;
        }

        public Builder setType(HotelType type) {
            this.type = type;
            return this;
        }

        public Builder setCancellable(boolean cancellable) {
            this.cancellable = cancellable;
            return this;
        }

        public Hotel build() {
            log.info("Napravljen je build hotela!");
            return new Hotel(this);
        }
    }

    @Override
    public boolean canBeCancelled() {
        log.info("Provjera može li se otkazati hotel!");
        return cancellable;
    }

    // Getteri
    public String getName() { return name; }
    public City getCity() { return city; }
    public String getAddress() { return address; }
    public Map<Integer, Room> getRooms() { return Collections.unmodifiableMap(rooms); }
    public List<Staff> getStaff() { return Collections.unmodifiableList(staff); }
    public boolean isCancellable() { return cancellable; }
    public HotelType getType() { return type; }

    // Pomoćne metode
    public void addRoom(Room room) {
        rooms.put(room.getRoomNumber(), room);
        log.info("Dodana soba broj: {}", room.getRoomNumber());
    }

    public Room getRoomByNumber(int number) {
        return rooms.get(number);
    }

    public void addStaffMember(Staff person) {
        staff.add(person);
        log.info("Dodano osoblje: {}", person.getName());
    }
}

