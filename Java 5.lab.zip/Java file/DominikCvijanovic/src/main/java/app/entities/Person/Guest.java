package app.entities.Person;


import java.math.BigDecimal;

import app.entities.Person.Person;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Radenje gosta hotela i clana bookinga
 *
 */

public class Guest extends Person {
    private static final Logger log = LoggerFactory.getLogger(Guest.class);

    private String email;

    public Guest(String name, String surname, String email, BigDecimal age) {
        super(name,surname,age);
        this.email = email;

        log.info("Kreiran je novi gost: {} {}", name,surname);
    }

    public BigDecimal getAge() {
        log.info("Pozvano je vracanje godina.");
        return age;
    }
    public void setAge(BigDecimal age) {
        this.age = age;
    }
    public String getEmail() {
        log.info("Pozvano je vracanje emaila.");
        return email;
    }
    public void setEmail(String email) { this.email = email; }


    @Override
    public void isPerson() {
        System.out.println("Osoba je gost!");
    }

}


