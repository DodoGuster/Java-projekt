package app.entities.Hotel;

public class InvalidHotelDataException extends RuntimeException {

    private final int hotelIndex;
    private final String hotelName;
    private final String address;
    private final String reason;

    public InvalidHotelDataException(int hotelIndex, String hotelName, String address, String reason) {
        super("Neispravan unos za " + hotelIndex + ". hotel" +
                " (ime: '" + hotelName + "', adresa: '" + address + "') – " + reason);
        this.hotelIndex = hotelIndex;
        this.hotelName = hotelName;
        this.address = address;
        this.reason = reason;
    }

}

