package app.entities.services;

import app.entities.Hotel.Hotel;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class HotelService {

    private final List<Hotel> hotels = new ArrayList<>();

    public void addHotel(Hotel h) {
        hotels.add(h);
    }

    public List<Hotel> getAll() {
        return hotels;
    }

    /**
     * Pronalazi hotel po imenu.
     * Vraća Optional<Hotel> umjesto null.
     */
    public Optional<Hotel> findByName(String name) {
        return hotels.stream()
                .filter(h -> h.getName().equalsIgnoreCase(name))
                .findFirst(); // Optional<Hotel>
    }
}
