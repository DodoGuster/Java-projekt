package app.entities.Person;


import java.math.BigDecimal;

/**
 * Spremanje placa zaposlenika
 *
 * @param salary
 */

public record Salary (BigDecimal salary) {}
