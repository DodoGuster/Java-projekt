package app.entities.UI;

import app.entities.Hotel.City;
import app.entities.Hotel.Hotel;
import app.entities.Hotel.Room;
import app.entities.Person.Guest;
import app.entities.Person.InvalidGuestDataException;
import app.entities.Reservations.Reservation;
import app.entities.services.GuestService;
import app.entities.services.HotelService;
import app.entities.services.ReservationService;
import app.entities.util.PrintUtils;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Map;
import java.util.Scanner;

public class UserIU {

    private static final int NUMBER = 2;

    private final HotelService hotelService;
    private final GuestService guestService;
    private final ReservationService reservationService;

    public UserIU(HotelService hotelService,
                  GuestService guestService,
                  ReservationService reservationService) {
        this.hotelService = hotelService;
        this.guestService = guestService;
        this.reservationService = reservationService;
    }

    public void run(Scanner unos) {
        unosGostiju(unos);
        rezervacijaHotela(unos);
    }

    private void unosGostiju(Scanner unos) {
        int br2 = 0;
        System.out.println("=== UNOS GOSTIJU ===");
        while (br2 < NUMBER) {
            System.out.println("Unesite ime " + (br2 + 1) + ". gosta:");
            String ime = unos.nextLine();
            guestService.findByName(ime)
                    .ifPresentOrElse(
                            guest -> {
                                System.out.println("Pronađen gost: "
                                        + guest.getName() + " " + guest.getSurname());
                                // ovdje ide daljnja logika – npr. kreiranje rezervacije
                            },
                            () -> {
                                System.out.println("❌ Gost s tim imenom ne postoji!");
                            }
                    );

            System.out.println("Unesite prezime " + (br2 + 1) + ". gosta:");
            String prezime = unos.nextLine();
            System.out.println("Unesite dob (npr. 31) " + (br2 + 1) + ". gosta:");
            BigDecimal dob = unos.nextBigDecimal();
            unos.nextLine();
            System.out.println("Unesite email gosta(ime@gmail.com): ");
            String email = unos.nextLine();
            try {
                String reason = null;

                if (ime.isEmpty() || prezime.isEmpty() || email.isEmpty()) {
                    reason = "ime, prezime i email su obavezni";
                } else if (dob.compareTo(BigDecimal.ONE) < 0 || dob.compareTo(new BigDecimal("100")) > 0) {
                    reason = "dob mora biti između 1 i 100 godina";
                }

                if (reason != null) {
                    throw new InvalidGuestDataException(ime, prezime, email, dob, reason);
                }

                guestService.addGuest(new Guest(ime, prezime, email, dob));
                br2++;

            } catch (InvalidGuestDataException e) {
                System.out.println(e.getMessage());
            }
        }
        System.out.println("Zavrsen unos gostiju!");
    }

    private void rezervacijaHotela(Scanner unos) {
        int br2 = 0;
        System.out.println("*** REZERVIRAJ SVOJ HOTEL ***\n");

        var hotels = hotelService.getAll();
        var guests = guestService.getAll();

        while (br2 < NUMBER) {
            int brojHotela = 0;
            System.out.println("Unesite grad u kojem želite rezervirati hotel (ZAGREB / OSIJEK): ");
            City grad = null;
            while (grad == null) {
                try {
                    grad = City.valueOf(unos.nextLine().trim().toUpperCase());
                } catch (IllegalArgumentException e) {
                    System.out.println("Nepoznat grad! Pokušajte ponovno.");
                }
            }

            System.out.println("Odaberite hotel:");
            for (int i = 0; i < hotels.size(); i++) {
                if (hotels.get(i).getCity().equals(grad)) {
                    System.out.println((i + 1) + ". HOTEL, grad: " + hotels.get(i).getCity() +
                            ", ime: " + hotels.get(i).getName() +
                            ", adresa: " + hotels.get(i).getAddress());
                }
            }

            System.out.println("Unesite broj hotela koji zelite rezervirati (npr. 1): ");
            while (brojHotela < 1 || brojHotela > hotels.size()) {
                brojHotela = unos.nextInt();
                if (brojHotela < 1 || brojHotela > hotels.size()) {
                    System.out.println("Krivi unos, ponovite unos broja hotela!");
                    brojHotela = 0;
                }
            }
            unos.nextLine();

            System.out.println("ODABIR SOBE:\nUnesite maksimalnu cijenu za jednu noc:");
            BigDecimal maksNoc = unos.nextBigDecimal();
            unos.nextLine();

            Map<Integer, Room> sobe = hotels.get(brojHotela - 1).getRooms();
            System.out.println("Dostupne sobe do cijene " + maksNoc + ":");
            for (Room room : sobe.values()) {
                BigDecimal cijena = room.getPricePerNight();
                if (cijena.compareTo(maksNoc) <= 0) {
                    System.out.println("Broj sobe: " + room.getRoomNumber() +
                            ", opis: " + room.getDescription() +
                            ", broj kreveta: " + room.getNumberOfBeds() +
                            ", cijena: " + room.getPricePerNight());
                }
            }

            System.out.println("Unesite broj sobe koju zelite: ");
            int brojSobe = unos.nextInt();
            unos.nextLine();

            Room odabranaSoba = sobe.get(brojSobe);
            if (odabranaSoba == null) {
                System.out.println("Ne postoji soba s tim brojem, uzimam prvu sobu iz ponude.");
                odabranaSoba = sobe.values().iterator().next();
            }

            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd.MM.yyyy");
            LocalDate startDate = null;
            LocalDate endDate = null;
            boolean provjera = false;

            do {
                try {
                    System.out.println("Unesite pocetni datum (01.01.2020): ");
                    startDate = LocalDate.parse(unos.nextLine(), formatter);
                    System.out.println("Unesite zavrsni datum (01.01.2020): ");
                    endDate = LocalDate.parse(unos.nextLine(), formatter);
                    provjera = true;
                } catch (java.time.format.DateTimeParseException e) {
                    System.out.println("Krivi format datuma! Molimo upišite točno u obliku dd.MM.yyyy");
                }
            } while (!provjera);

            System.out.println("Za potvrdu rezervacije unesite Vase ime i prezime!\nUnos imena: ");
            String ime = unos.nextLine();
            System.out.println("Unos prezimena: ");
            String prezime = unos.nextLine();

            Guest gostUnos = guests.stream()
                    .filter(g -> g.getName().equalsIgnoreCase(ime) && g.getSurname().equalsIgnoreCase(prezime))
                    .findFirst()
                    .orElse(null);

            if (gostUnos == null) {
                System.out.println("Korisnik ne postoji ili je krivo unesen!");
            } else {
                reservationService.addReservation(
                        new Reservation(hotels.get(brojHotela - 1),
                                odabranaSoba, startDate, endDate, gostUnos)
                );
                System.out.println("Hvala na rezervaciji!");
                br2++;
            }
        }

        System.out.println("Rezrvacija hotela odradena!");
    }
}
