package app.entities.Hotel;


/**
 * Omogucava otkzavianje rezervacije hotela
 *
 * @return true ako se moze otkazazi, false ako se ne moze
 */

public interface Cancelable {
    boolean canBeCancelled();
}
