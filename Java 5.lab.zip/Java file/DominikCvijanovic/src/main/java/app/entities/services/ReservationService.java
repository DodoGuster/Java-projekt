package app.entities.services;

import app.entities.Person.Guest;
import app.entities.Reservations.Reservation;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class ReservationService {

    private final List<Reservation> reservations = new ArrayList<>();

    public void addReservation(Reservation reservation) {
        reservations.add(reservation);
    }

    public List<Reservation> getAll() {
        return reservations;
    }

    /**
     * Pronalazi prvu rezervaciju za zadanog gosta.
     * Vraća Optional<Reservation>.
     */
    public Optional<Reservation> findByGuest(Guest guest) {
        return reservations.stream()
                .filter(r -> r.getGuest().equals(guest))
                .findFirst();
    }
}
