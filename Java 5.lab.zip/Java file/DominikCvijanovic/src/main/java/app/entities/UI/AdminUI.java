package app.entities.UI;

import app.entities.Hotel.City;
import app.entities.Hotel.Hotel;
import app.entities.Hotel.InvalidHotelDataException;
import app.entities.Hotel.Room;
import app.entities.Person.Guest;
import app.entities.Person.Salary;
import app.entities.Person.Staff;
import app.entities.services.HotelService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import app.entities.util.PrintUtils;

import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;

public class AdminUI {
    private static final Logger log = LoggerFactory.getLogger(AdminUI.class);
    private static final int NUMBER = 2;
    private static final BigDecimal maxRoomPrice = new BigDecimal("500.00");

    private final HotelService hotelService;

    public AdminUI(HotelService hotelService) {
        this.hotelService = hotelService;
    }

    public void run(Scanner unos) {

        int br2 = 0;
        log.info("Ulaz u unos hotela i osoblja!");
        System.out.println("Unos hotela i soba!");

        while (br2 < NUMBER) {
            System.out.println("Unesite ime " + (br2 + 1) + ". hotela:");
            String imeHotela = unos.nextLine();

            City city = null;
            while (city == null) {
                try {
                    System.out.println("Odaberite grad (ZAGREB / OSIJEK):");
                    city = City.valueOf(unos.nextLine().trim().toUpperCase());
                } catch (IllegalArgumentException e) {
                    System.out.println("Nepoznat grad! Pokušajte ponovno.");
                }
            }

            System.out.println("Unesite adresu hotela:");
            String adresa = unos.nextLine();

            try {
                if (imeHotela.isEmpty()) {
                    throw new InvalidHotelDataException(
                            br2 + 1,
                            imeHotela,
                            adresa,
                            "ime hotela ne smije biti prazno"
                    );
                }
                if (adresa.isEmpty()) {
                    throw new InvalidHotelDataException(
                            br2 + 1,
                            imeHotela,
                            adresa,
                            "adresa hotela ne smije biti prazna"
                    );
                }
            } catch (InvalidHotelDataException e) {
                System.out.println(e.getMessage());
                log.error(e.getMessage());
                continue;
            }

            int br = 0; // brojac soba
            Map<Integer, Room> rooms = new HashMap<>();

            while (br < NUMBER) {
                boolean valid = false;
                do {
                    System.out.println("Unesite opis " + (br + 1) + ". sobe u hotelu:");
                    String opis = unos.nextLine();

                    System.out.println("Unesite broj kreveta te sobe:");
                    int broj = unos.nextInt();

                    System.out.println("Unesite cijenu noćenja u toj sobi: ");
                    BigDecimal nocenje = unos.nextBigDecimal();
                    unos.nextLine();

                    try {
                        if (nocenje.compareTo(BigDecimal.ZERO) <= 0)
                            throw new IllegalArgumentException("Cijena noćenja mora biti veća od 0!");

                        if (opis.length() < 5 || broj < 1) {
                            System.out.println("Krivi upis, ponovite upis " + (br + 1) + ". sobe");
                        } else {
                            int roomNumber = br + 1;
                            rooms.put(roomNumber, new Room(roomNumber, nocenje, opis, broj));
                            br++;
                            valid = true;
                        }

                    } catch (IllegalArgumentException e) {
                        log.error(e.getMessage());
                        System.out.println("⚠️ " + e.getMessage());
                    }

                } while (!valid);
            }

            //U slučaju da je soba preskupa!!!
            Map<Integer, Room> sortedRooms = rooms.entrySet().stream()
                    .filter(entry -> entry.getValue().getPricePerNight().compareTo(maxRoomPrice) <= 0)
                    .sorted(Comparator.comparing(e -> e.getValue().getPricePerNight()))
                    .collect(Collectors.toMap(
                            Map.Entry::getKey,
                            Map.Entry::getValue,
                            (a, b) -> a,
                            LinkedHashMap::new
                    ));

            PrintUtils.printList(sortedRooms.values());

            log.info("Unos hotela je zavrsen!");
            log.trace("Broj kreiranih hotela: " + NUMBER);

            System.out.println(
                    "Unjeli ste sobe, slijedi unos osoblja hotela!\nUnesite koliko zaposlenika ima hotel(npr. 3):"
            );
            int brZaposlenika = unos.nextInt();
            unos.nextLine();

            List<Staff> staff = new ArrayList<>();
            for (int i = 0; i < brZaposlenika; i++) {
                System.out.println("Unesite ime " + (i + 1) + ". zaposlenika:");
                String ime = unos.nextLine();
                System.out.println("Unesite prezime " + (i + 1) + ". zaposlenika:");
                String prezime = unos.nextLine();
                System.out.println("Unesite vrstu posla " + (i + 1) + ". zaposlenika(npr. konobar):");
                String vrstaPosla = unos.nextLine();
                System.out.println("Unesite placu " + (i + 1) + ". zaposlenika(npr. 1100):");
                BigDecimal placa = unos.nextBigDecimal();
                unos.nextLine();
                System.out.println("Unesite dob " + (i + 1) + ". zaposlenika(npr. 31):");
                BigDecimal dob = unos.nextBigDecimal();
                unos.nextLine();
                Salary salary = new Salary(placa);
                Staff zaposlenik = new Staff(ime, prezime, vrstaPosla, salary, dob);
                staff.add(zaposlenik);
            }

            staff.sort(Comparator.comparing(Staff::getSurname)
                    .thenComparing(Staff::getName)
            );

            System.out.println("Moze li se rezervacija hotela otkazati nakon rezervacije(Upisite: true ili false):");
            boolean cancelable = unos.nextBoolean();
            unos.nextLine();
            Hotel hotel = new Hotel.Builder(imeHotela, city, adresa)
                    .setRooms(sortedRooms)
                    .setStaff(staff)
                    .setCancellable(cancelable)
                    .build();

            hotelService.addHotel(hotel);

            br2++;
            log.info("Kreiran hotel broj: {}", br2);
        }

        log.info("Zavrsen unos hotela!");
    }
}
